# LEO Konferenzmodus – Erweiterung für KI-Lehrling 2.1

Die Erweiterung erhält die bisherigen Unterrichtsmodule und startet separat per `?conference=1`.

## Einbau in dein bestehendes GitHub-Repository

1. Lade `conference_mode.py` ins **Hauptverzeichnis** deines Repositories hoch (neben `app.py`).
2. Öffne `app.py` und füge **direkt nach** der vorhandenen Zeile `st.set_page_config(...)` Folgendes ein:

```python
from conference_mode import run_conference
if st.query_params.get("conference") == "1":
    run_conference()
    st.stop()
```

3. Übernimm/committe die Änderung in GitHub. Deine bereits veröffentlichte Streamlit-App wird nach dem Redeployment weiter wie bisher laufen.
4. Für den Konferenzmodus ergänze `?conference=1` an die Adresse deiner Streamlit-App (oder `&conference=1`, wenn die URL bereits einen Parameter hat).
5. Für die **optionale echte KI** müssen die bisherigen Streamlit-Secrets weiterhin gesetzt sein: `API_KEY`, `BASE_URL`, `MODEL`. Die Schlüssel niemals in GitHub veröffentlichen.

## Benutzung

- Mit **Weiter** und **Zurück** durch zehn vorbereitete Szenen wechseln.
- **Regie ein-/ausblenden** für Hilfstexte, 60-Sekunden-Timer, Live-KI-Schalter und Eingabe.
- Im Offline-Modus laufen alle zehn vorbereiteten Szenen ohne API-Aufruf; die Streamlit-Webanwendung selbst braucht zum Laden weiterhin Internet oder einen lokalen Streamlit-Server.
- Im Live-Modus werden Antworten über die bestehende Groq-kompatible API generiert; bei Fehlern bleibt das vorbereitete Drehbuch nutzbar.

## Wichtige Einschränkung

Dies ist eine **einzelne Browseransicht**. Eine unabhängige zweite, synchronisierte Regie- und Publikumsansicht ist hier noch nicht implementiert. Für den Vortrag: erst am Laptop in der Regie vorbereiten, Regie einklappen und dann den Browser projizieren. Eine vollständig von Streamlit unabhängige Offline-HTML-Datei ist im früheren Demo-Paket enthalten; diese Python-Erweiterung ist kein Offline-Standaloneprogramm.

## Sicherheit / fachliche Prüfung

Die KI kann sich irren. Vor dem Live-Auftritt mit mehreren Publikumsantworten testen. Kein unsicheres Rollenspiel als elektrotechnische Handlungsanweisung ausgeben. Backup-Drehbuch ausdrücklich verwenden, wenn Verbindung oder Modell unzuverlässig ist.
